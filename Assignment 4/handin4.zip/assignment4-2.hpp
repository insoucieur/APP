#include <vector>
#include <algorithm>
#include "Vector_old.hpp"

// Computes the distances of all points in the range [begin,end) to a given query point.
//
// The results are stored in the Range starting with distanceBegin having the same length
// as the range of points. The i-th element of the range stores the distance of the i-th point
// in the range to the query point as a double value.
//
// The supplied iterators can be assumed to be bidirectional
template<class SetIterator, class DistanceIterator>
void computeDistances(
	SetIterator begin, SetIterator end,//pointers to the start and end of the set of points
	Vector const& query, //the query point
	DistanceIterator distanceBegin //iterator to the beginning of the range storing the distances
){
    while(begin != end)
        {*distanceBegin++ = (*begin++ - query).CalculateNorm();}
}

// class representing a Pair of a distance and an iterator to the point
// with the distance to a query point.
template<class Iterator>
struct Pair{
	double distance;
	Iterator iterator;
};

// Computes the distances of all points in the range [begin,end) to a given query point
// and returns a sorted array of pairs: the distance to the query point and the iterator
// in the range that has this distance.
//
// Elements are returned in ascending order, i.e. the pair with the smallest distance
// is at the front, next is the pair with the second smallest distance, etc.
template<class SetIterator>
std::vector<Pair<SetIterator> > createSortedPointDistancePairs(
	SetIterator begin, SetIterator end,//pointers to the start and end of the set of points
	Vector const& query //the query point
){
    int l = std::distance(begin, end); //get length of SetIterator
    std::vector<double> distances(l); //make a vector same length as SetIterator
    computeDistances(begin, end, query, distances.begin()); //calculate distances using above function

    std::vector<Pair<SetIterator>> v(l); //tp access members in struct Pair
    for (int i = 0; i < l; i++) //iterate through the length of the vector
        v[i] = Pair<SetIterator>{distances[i], begin+i};

    std::sort(v.begin(), v.end(),
            [](Pair<SetIterator> a, Pair<SetIterator> b) {
                return a.distance < b.distance;
            });
    return v;
}

//Returns the Iterators to the k nearest neighbours of a given query point.
//
// The iterators are sorted in ascending order by distance to the query point.
//
// The set of points is given in the range [begin,end].
template<class SetIterator>
std::vector<SetIterator> kNearestNeighbour(
	SetIterator begin, SetIterator end,//pointers to the start and end of the set of points
	Vector const& query, //the query point
	unsigned int k // the k nearest neighbours that are going to be returned
){
    auto all = createSortedPointDistancePairs(begin, end, query); //any type
    std::vector<SetIterator> k_nearest(k); //new vector that is same length as k to store resultsof k nearest neighbours
    for (unsigned i = 0; i < k; i++)
        k_nearest[i] = all[i].iterator;
    return k_nearest;
}

